package com.rabbitmq.rabbitmq;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.rabbitmq.bean.Email;
import com.rabbitmq.bean.EmailBuilder;

@SpringBootApplication
public class RabbitmqApplication implements CommandLineRunner {

	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	public static void main(String[] args) {
		SpringApplication.run(RabbitmqApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Email email  = new EmailBuilder()
				.setId(2)
				.setSender("sender@amqp.com")
				.setReceiver("receiver@amqp.com")
				.setBody("test message")
				.build();
				
		rabbitTemplate.convertAndSend("TestExchange", "testRouting", email);
	}

}
