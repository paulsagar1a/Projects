package com.rabbitmq.bean;

public class EmailBuilder {
	private Email email;
	
	public EmailBuilder() {
		email = new Email();
	}
	
	public EmailBuilder setId(int id) {
		this.email.setId(id);
		return this;
	}
	public EmailBuilder setSender(String sender) {
		this.email.setSender(sender);
		return this;
	}
	public EmailBuilder setReceiver(String receiver) {
		this.email.setReceiver(receiver);
		return this;
	}
	public EmailBuilder setBody(String body) {
		this.email.setBody(body);
		return this;
	}
	public EmailBuilder setSignature(String signature) {
		this.email.setSignature(signature);
		return this;
	}
	
	public Email build() {
		return email;
	}
}
