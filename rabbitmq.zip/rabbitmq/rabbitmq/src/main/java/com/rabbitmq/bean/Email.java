package com.rabbitmq.bean;

import java.io.Serializable;

public class Email implements Serializable {
	int id;
	String sender;
	String receiver;
	String body;
	String signature;
	
	public Email() {}
	
	

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getSender() {
		return sender;
	}



	public void setSender(String sender) {
		this.sender = sender;
	}



	public String getReceiver() {
		return receiver;
	}



	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}



	public String getBody() {
		return body;
	}



	public void setBody(String body) {
		this.body = body;
	}



	public String getSignature() {
		return signature;
	}



	public void setSignature(String signature) {
		this.signature = signature;
	}



	@Override
	public String toString() {
		return "Email [id=" + id + ", sender=" + sender + ", receiver=" + receiver + ", body=" + body + ", signature="
				+ signature + "]";
	}
	
}
