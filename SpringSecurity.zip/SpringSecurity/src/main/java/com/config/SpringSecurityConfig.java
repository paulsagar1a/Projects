package com.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.JdbcUserDetailsManager;

@Configuration
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {
	/**
	 * /myAccount - Secured
	 * /myBalance - Secured
	 * /myLoans - Secured
	 * /myCards - Secured
	 * /notices - Not Secured
	 * /contact - Not Secured
	 * /hackAccounts - Deny
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		System.out.println("===> HttpSecurity configuration start");
		//http.authorizeRequests((requests) -> requests.anyRequest().authenticated());
		http.authorizeRequests()
			.antMatchers("/myAccount").hasAnyAuthority("WRITE")
			//.antMatchers("/myAccount").hasAnyRole("admin", "user")
			.antMatchers("/myBalance").hasAnyAuthority("READ")
			.antMatchers("/myLoans").hasAuthority("DELETE")
			.antMatchers("/myCards").authenticated()
			.antMatchers("/notices").permitAll()
			.antMatchers("/contact").permitAll()
			.antMatchers("/hackAccounts").denyAll()
			.antMatchers("/h2-console/**").permitAll(); //add h2-console URL
		
		http.headers().frameOptions().disable(); //add this line to access h2-console
		http.csrf().disable(); //add this line to access h2-console
		//http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS); //add this line if we do not want to use any session like JSESSIONID
		http.formLogin();
		http.httpBasic();
		System.out.println("===> HttpSecurity configuration ends");
	}
	
	/*
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		//In-memory authentication method-1
		InMemoryUserDetailsManager userDetailsService = new InMemoryUserDetailsManager();
		UserDetails admin1 = User.withUsername("admin1").password("admin123").authorities("admin").build();
		UserDetails user1 = User.withUsername("user1").password("user123").authorities("read").build();
		UserDetails user2 = User.withUsername("user2").password("user123").authorities("read").build();
		
		userDetailsService.createUser(admin1);
		userDetailsService.createUser(user1);
		userDetailsService.createUser(user2);
		auth.userDetailsService(userDetailsService);
		
		//In-memory authentication method-2
		auth.inMemoryAuthentication()
			.withUser("admin").password("admin123").roles("USER")
			.and()
			.withUser("user").password("user123").roles("USER")
			.and()
			.passwordEncoder(NoOpPasswordEncoder.getInstance());
		
	}
	*/
	
	/*
	@Bean
	public UserDetailsService UserDetailsService(DataSource dataSource) {
		return new JdbcUserDetailsManager(dataSource);
	}
	*/
	
	@Bean
	public PasswordEncoder passwordEncoden() {
		return NoOpPasswordEncoder.getInstance();
	}
}
