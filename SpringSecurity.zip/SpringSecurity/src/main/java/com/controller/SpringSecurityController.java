package com.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class SpringSecurityController {

	@GetMapping("/myAccount")
	public String getMyAccount() {
		return "Welcome to myAccouunt.";
	}
	
	@GetMapping("/myBalance")
	public String getMyBalance() {
		return "The Balance is $100.";
	}
	
	@GetMapping("/myLoans")
	public String getMyLoans() {
		return "The Loan amount is $25.";
	}
	
	@GetMapping("/myCards")
	public String getMyCards() {
		return "Card Number BA0001RB004.";
	}
	
	@GetMapping("/notices")
	public String getMyNotices() {
		return "Easy Bank offers home loan with 8.23% interest.";
	}
	
	@GetMapping("/contact")
	public String getMyContact() {
		return "Manager Email: EASY_BANK@help.easy.com";
	}
}
