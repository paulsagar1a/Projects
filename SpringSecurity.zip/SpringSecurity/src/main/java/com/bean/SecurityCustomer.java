package com.bean;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.springframework.security.access.AuthorizationServiceException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javassist.SerialVersionUID;

public class SecurityCustomer implements  UserDetails {
	private static final long SerialVersionUID = 1L;
	private final Customer customer;
	
	public SecurityCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() throws AuthorizationServiceException {
		//List<GrantedAuthority> authorities = new ArrayList<>();
		//authorities.add(new SimpleGrantedAuthority(customer.getRole()));
		Set<Authority> authorities = customer.getAuthorities();
		if(authorities.size() == 0) {
			throw new AuthorizationServiceException("Authorization failed for the customer : "+customer.getUsername());
		}
		return getGrantedAuthorities(authorities);
	}
	
	private List<GrantedAuthority> getGrantedAuthorities(Set<Authority> authorities) {
		List<GrantedAuthority> grantedAuthority = new ArrayList<>();
		for(Authority authority : authorities) {
			grantedAuthority.add(new SimpleGrantedAuthority(authority.getName()));
		}
		return grantedAuthority;
	}

	@Override
	public String getPassword() {
		return customer.getPassword();
	}

	@Override
	public String getUsername() {
		return customer.getUsername();
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return customer.isEnabled();
	}

}
