/*
-- Default spring security configuration with users and authorities tables
drop table users if exists;
create table users (
	id int not null auto_increment,
	username varchar(20) not null unique,
	password varchar(20) not null,
	enabled boolean not null default false,
	primary key (id)
);

drop table authorities if exists;
create table authorities (
	id int not null auto_increment,
	username varchar(20) not null unique,
	authority varchar(20) not null,
	primary key (id)
);
*/

-- Custom spring security configuration with customer table
drop table customer if exists;
create table customer (
	id int not null auto_increment,
	username varchar(20) not null unique,
	email varchar(40) not null unique,
	password varchar(20) not null,
	role varchar(20) not null,
	enabled boolean not null default false,
	primary key (id)
);

drop table authorities if exists;
create table authorities (
	id int not null auto_increment,
	customer_id int not null,
	authority varchar(20) not null,
	primary key (id)
);