/*
-- Default spring security configuration with users and authorities tables
insert into users (username, password, enabled) values ('admin1', 'admin123', true);
insert into users (username, password, enabled) values ('admin2', 'admin123', true);
insert into users (username, password, enabled) values ('user1', 'user123', true);
insert into users (username, password) values ('user2', 'user123');

insert into authorities (username, authority) values ('admin1', 'admin');
insert into authorities (username, authority) values ('admin2', 'admin');
insert into authorities (username, authority) values ('user1', 'read');
insert into authorities (username, authority) values ('user2', 'read');
*/

-- Custom spring security configuration with customer table
insert into customer (username, email, password, role, enabled) 
values ('admin1', 'admin1@spring.com', 'admin123', 'admin', true);
insert into customer (username, email, password, role, enabled) 
values ('user1', 'user1@spring.com', 'user123', 'user', true);
insert into customer (username, email, password, role, enabled) 
values ('user2', 'user2@spring.com', 'user123', 'user', false);

insert into authorities (customer_id, authority) values (1, 'WRITE');
insert into authorities (customer_id, authority) values (1, 'READ');
insert into authorities (customer_id, authority) values (2, 'READ');