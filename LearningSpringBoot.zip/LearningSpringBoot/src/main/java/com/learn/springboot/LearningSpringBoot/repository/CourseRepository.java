package com.learn.springboot.LearningSpringBoot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.transaction.annotation.Transactional;

import com.learn.springboot.LearningSpringBoot.bean.Course;

@RepositoryRestResource(path="data-rest-courses")
@Transactional
public interface CourseRepository extends JpaRepository<Course, Integer> {

	Course findByName(String name);
	
	@Query(value = "SELECT * FROM course  WHERE instractor = ?1", nativeQuery = true)
	Course findByInstractor(String instractor);
	
	@Query(value = "SELECT c FROM Course c WHERE price >= ?1")
	List<Course> findByPrice(double price);

}
