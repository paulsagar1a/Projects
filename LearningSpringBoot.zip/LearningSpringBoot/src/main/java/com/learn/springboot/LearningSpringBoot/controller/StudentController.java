package com.learn.springboot.LearningSpringBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learn.springboot.LearningSpringBoot.bean.Student;
import com.learn.springboot.LearningSpringBoot.repository.StudentRepository;

@RestController
@RequestMapping("/")
public class StudentController {
	@Autowired
	private StudentRepository studentRepository;
	
	@GetMapping("/students")
	public List<Student> getAllStudent() {
		return studentRepository.findAll();
	}
	
	@GetMapping("/students/{id}")
	public Student getStudentById(@PathVariable(value = "id") int id) throws Exception {
		return studentRepository.findById(id)
				.orElseThrow(() -> new Exception("Student not found by the id "+id));
		
	}
	
	@PutMapping("/students/{id}")
	public Student updateStudent(@PathVariable(value = "id") int id, @RequestBody Student studentDetails) throws Exception {
		Student student = studentRepository.findById(id)
				.orElseThrow(() -> new Exception("Student not found by the id "+id));
		student.setName(studentDetails.getName());
		return studentRepository.save(student);
	}
	
	@PostMapping("/students")
	public Student saveStudent(@Validated @RequestBody Student studentDetails) {
		return studentRepository.save(studentDetails);
	}
	
	@DeleteMapping("/students/{id}")
	public Student deleteStudent(@PathVariable(value="id") int id) throws Exception {
		Student student = studentRepository.findById(id)
				.orElseThrow(() -> new Exception("Student not found by the id "+id));
		studentRepository.delete(student);
		return student;
	}
	
}
