package com.learn.springboot.LearningSpringBoot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.transaction.annotation.Transactional;

import com.learn.springboot.LearningSpringBoot.bean.Student;

@RepositoryRestResource(path="data-rest-students")
public interface StudentRepository extends JpaRepository<Student, Integer>{

}
