package com.learn.springboot.LearningSpringBoot.bean;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@NamedQueries(value = {
		@NamedQuery(name = "query_get_all_courses", query = "select c from Course c"),
		@NamedQuery(name = "query_get_all_courses_count", query = "select count(c) from Course c"),
		@NamedQuery(name = "query_get_all_courses_join_fetch", query = "select c from Course c JOIN FETCH c.students s")
})
@Table(name="course")
public class Course {
	@Id
	@GeneratedValue
	@Column(name="id")
	private int id;
	@Column(name="name")
	private String name;
	@Column(name="price")
	private double price;
	@Column(name="instractor")
	private String instractor;
	@Column(name="start_date")
	private LocalDateTime startDate;
	@Column(name="end_date")
	private LocalDateTime endDate;
	@OneToMany(mappedBy = "course")
	private List<Review> reviews = new ArrayList<>(); //non-owning side of relationship
	@JsonIgnore
	@ManyToMany(mappedBy = "courses") //any mapping ending with 'ToMany'is a LAZY fetch
	private List<Student> students = new ArrayList<>();
	
	public Course() {
		super();
	}

	public Course(String name, double price, String instractor, LocalDateTime startDate, LocalDateTime endDate) {
		super();
		this.name = name;
		this.price = price;
		this.instractor = instractor;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getInstractor() {
		return instractor;
	}

	public void setInstractor(String instractor) {
		this.instractor = instractor;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	public List<Review> getReviews() {
		return reviews;
	}

	public void addReview(Review review) {
		this.reviews.add(review);
	}
	
	public void removeReview(Review review) {
		this.reviews.remove(review);
	}

	public List<Student> getStudents() {
		return students;
	}

	public void addStudent(Student student) {
		this.students.add(student);
	}

	@Override
	public String toString() {
		return "Course [id=" + id + ", name=" + name + ", price=" + price + ", instractor=" + instractor
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", reviews=" + reviews + ", students="
				+ students + "]";
	}

}
