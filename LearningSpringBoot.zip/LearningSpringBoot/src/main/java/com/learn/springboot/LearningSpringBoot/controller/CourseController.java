package com.learn.springboot.LearningSpringBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learn.springboot.LearningSpringBoot.bean.Course;
import com.learn.springboot.LearningSpringBoot.repository.CourseRepository;

@RestController
@RequestMapping("/")
public class CourseController {
	@Autowired
	private CourseRepository courseRepository;
	
	@GetMapping("/courses/{id}")
	public Course getCourseById(@PathVariable(value="id") int id) throws Exception {
		return courseRepository.findById(id)
				.orElseThrow(() -> new Exception("Course not found by the id "+id));
	}
	
	@GetMapping("/courses")
	public List<Course> getAllCourses() {
		return courseRepository.findAll();
	}
	
	@PostMapping("/courses")
	public Course createCourse(@RequestBody Course course) {
		return courseRepository.save(course);
	}
	
	@PutMapping("/courses/{id}")
	public Course updateCourse(@PathVariable(value = "id") int id, @RequestBody Course courseDetails) throws Exception {
		Course course = courseRepository.findById(id)
				.orElseThrow(() -> new Exception("Course not found by the id "+id));
		course.setName(courseDetails.getName());
		course.setPrice(courseDetails.getPrice());
		course.setInstractor(courseDetails.getInstractor());
		course.setStartDate(courseDetails.getStartDate());
		course.setEndDate(courseDetails.getEndDate());
		return courseRepository.save(course);
	}
	
	@DeleteMapping("/courses/{id}")
	public Course deleteById(@PathVariable(value = "id") int id) throws Exception {
		Course course = courseRepository.findById(id)
				.orElseThrow(() -> new Exception("Course not found by the id "+id));
		courseRepository.delete(course);
		return course;
	}
	
	@GetMapping("/courses/name/{name}")
	public Course findByName(@PathVariable(value = "name") String name) {
		return courseRepository.findByName(name);
	}
	
	@GetMapping("/courses/instractor/{instractor}")
	public Course findByInstractor(@PathVariable(value = "instractor") String instractor) {
		System.out.println("instractor name = "+instractor);
		return courseRepository.findByInstractor(instractor);
	}
}
