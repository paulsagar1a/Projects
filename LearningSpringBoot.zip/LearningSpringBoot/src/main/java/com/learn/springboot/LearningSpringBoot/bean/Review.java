package com.learn.springboot.LearningSpringBoot.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "review")
public class Review {
	@Id
	@GeneratedValue
	private int id;
	@Column(nullable = true)
	private String description;
	private double rating;
	@JsonIgnore
	@ManyToOne
	private Course course; //owning side of the relationship
	
	public Review() {
		super();
	}
	
	public Review(String description, double rating) {
		super();
		this.description = description;
		this.rating = rating;
	}

	public int getId() {
		return id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	@Override
	public String toString() {
		return "Review [id=" + id + ", description=" + description + ", rating=" + rating + ", course=" + course + "]";
	}
	
}
