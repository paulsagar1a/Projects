package com.learn.springboot.LearningSpringBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learn.springboot.LearningSpringBoot.bean.Passport;
import com.learn.springboot.LearningSpringBoot.repository.PassportRepository;

@RestController
@RequestMapping("/")
public class PassportController {
	@Autowired
	private PassportRepository passportRepository;
	
	@GetMapping("/passports")
	public List<Passport> getAllPassport() {
		return passportRepository.findAll();
	}
	
	@GetMapping("/passports/{id}")
	public Passport getPassportById(@PathVariable(value = "id") int id) throws Exception {
		return passportRepository.findById(id)
				.orElseThrow(() -> new Exception("Passports not found by the id "+id));
		
	}
}
