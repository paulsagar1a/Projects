-- course table
insert into course (name, price, instractor, start_date, end_date) values
('Python', 549.99, 'Uday Sharma', '2021-04-04',  '2021-07-04');
insert into course (name, price, instractor, start_date, end_date) values
('Java', 734.00, 'Manika Reddy', '2021-05-05',  '2021-07-19');
insert into course (name, price, instractor, start_date, end_date) values
('Kotlin', 450.00, 'Manika Reddy', '2021-07-26',  '2021-10-04');
insert into course (name, price, instractor, start_date, end_date) values
('C++', 299.99, 'Anmol Jain', '2021-04-04',  '2021-06-04');
insert into course (name, price, instractor, start_date, end_date) values
('R', 549.99, 'Uday Sharma', '2021-07-11',  '2021-09-14');

-- student table
insert into student (name, passport_id) values ('Sanjay Mallik', 1);
insert into student (name, passport_id) values ('Lalita Das', 2);
insert into student (name, passport_id) values ('Kakoli Ghosh', 3);

-- passport table
insert into passport (number) values ('N10204983');
insert into passport (number) values ('N10204000');
insert into passport (number) values ('N10323330');

-- review table
insert into review (description, rating, course_id) values ('Greate Course', 5, 1);
insert into review (description, rating, course_id) values ('Wonderful Course', 4.2, 2);
insert into review (description, rating, course_id) values ('Greate Course', 4.8, 3);
insert into review (description, rating, course_id) values ('Awesome Course', 4, 2);
insert into review (description, rating, course_id) values('Moderate Course', 3.5, 4);

-- student_course table
insert into student_course (student_id, course_id) values (1, 1);
insert into student_course (student_id, course_id) values (1, 2);
insert into student_course (student_id, course_id) values (1, 3);
insert into student_course (student_id, course_id) values (1, 5);
insert into student_course (student_id, course_id) values (2, 1);
insert into student_course (student_id, course_id) values (2, 2);
insert into student_course (student_id, course_id) values (2, 3);
insert into student_course (student_id, course_id) values (2, 4);
insert into student_course (student_id, course_id) values (3, 4);
insert into student_course (student_id, course_id) values (3, 5);