drop table course if exists;
create table course (
	id int not null AUTO_INCREMENT primary key,
	name varchar(25) not null,
	price float not null,
	instractor varchar(25) not null,
	start_date datetime null,
	end_date datetime null
);

drop table passport if exists;
create table passport (
	id int not null AUTO_INCREMENT primary key,
	number varchar(10) not null
);

drop table student if exists;
create table student (
	id int not null AUTO_INCREMENT primary key,
	name varchar(25) not null,
	passport_id int not null
);

drop table review if exists;
create table review (
	id int not null AUTO_INCREMENT primary key,
	description varchar(25) not null,
	rating float null,
	course_id int not null
);

drop table student_course if exists;
create table student_course (
	student_id int not null, 
	course_id int not null
);
