package com.learn.springboot.LearningSpringBoot.test.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import com.learn.springboot.LearningSpringBoot.LearningSpringBootApplication;
import com.learn.springboot.LearningSpringBoot.bean.Passport;
import com.learn.springboot.LearningSpringBoot.repository.PassportRepository;

@SpringBootTest(classes=LearningSpringBootApplication.class)
public class PassportControllerTest {
	@Autowired
	PassportRepository passportRepository;

	@Test
	@DirtiesContext
	public void testFindPassportById() {
		System.out.println("testFindPassportById");
		Passport passport = passportRepository.findById(2).orElse(new Passport());
		System.out.println("===>"+passport);
		System.out.println("===>"+passport.getStudent());
		assertNotNull(passport);
	}
}
