package com.learn.springboot.LearningSpringBoot.test.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.learn.springboot.LearningSpringBoot.LearningSpringBootApplication;
import com.learn.springboot.LearningSpringBoot.bean.Student;
import com.learn.springboot.LearningSpringBoot.repository.StudentRepository;

@SpringBootTest(classes=LearningSpringBootApplication.class)
public class StudentControllerTest {
	@Autowired
	StudentRepository studentRepository;

	@Test
	@DirtiesContext
	@Transactional(isolation = Isolation.READ_COMMITTED)
	public void testFindStudentById() {
		System.out.println("testFindStudentById");
		Student student = studentRepository.findById(1).orElse(new Student());
		System.out.println("===>"+student);
		System.out.println("===>"+student.getPassport());
		System.out.println("===>"+student.getCourses());
		assertNotNull(student);
	}
}
