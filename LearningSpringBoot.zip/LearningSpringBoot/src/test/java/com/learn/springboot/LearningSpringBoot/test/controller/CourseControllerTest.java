package com.learn.springboot.LearningSpringBoot.test.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.Subgraph;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.transaction.annotation.Transactional;

import com.learn.springboot.LearningSpringBoot.LearningSpringBootApplication;
import com.learn.springboot.LearningSpringBoot.bean.Course;
import com.learn.springboot.LearningSpringBoot.bean.Student;
import com.learn.springboot.LearningSpringBoot.repository.CourseRepository;
import com.learn.springboot.LearningSpringBoot.repository.StudentRepository;

@SpringBootTest(classes=LearningSpringBootApplication.class)
public class CourseControllerTest {
	@Autowired
	CourseRepository courseRepository;
	@Autowired
	EntityManager entityManager;
	
	@Before(value = "")
	public void testBefore() {
		System.out.println("before courseRepository "+courseRepository.count());
	}
	@After(value = "")
	public void testAfter() {
		System.out.println("after courseRepository "+courseRepository.count());
	}
	
	@Test
	public void testGetAllCourses() {
		System.out.println("testGetAllCourses");
		Course course = courseRepository.findById(2).orElse(new Course());
		System.out.println(course);
		assertNotNull(course);
	}
	
	@Test
	public void testFindByInstractor() {
		System.out.println("testGetAllCourses");
		Course course = courseRepository.findByInstractor("Uday Sharma");
		System.out.println(course);
		assertNotNull(course);
	}
	
	@Test
	@DirtiesContext
	public void testFindByPrice() {
		System.out.println("testFindByPrice");
		List<Course> course = courseRepository.findByPrice(500.00);
		System.out.println(course);
		assertNotNull(course);
	}
	
	//Avoid N+1 problem 
	@Test
	@Transactional
	public void solvingNPlusProblem_EntityGraph() {
		EntityGraph<Course> entityGraph = entityManager.createEntityGraph(Course.class);
		Subgraph<Object> subGraph = entityGraph.addSubgraph("students");
		
		List<Course> courses = entityManager.createNamedQuery("query_get_all_courses",Course.class)
				.setHint("javax.persistence.loadgraph", entityGraph)
				.getResultList();
		for(Course course : courses) {
			System.out.printf("\n===> Course %s \n===> student %s", course, course.getStudents());
		}
		
	}
	
	//Avoid N+1 problem 
	@Test
	@Transactional
	public void solvingNPlusProblem_JoinFetch() {		
		List<Course> courses = entityManager.createNamedQuery("query_get_all_courses_join_fetch",Course.class)
				.getResultList();
		for(Course course : courses) {
			System.out.printf("\n===> Course %s \n===> student %s", course, course.getStudents());
		}
		
	}
}
