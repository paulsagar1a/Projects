package quize.quizeapp;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestQuize {

	@Test
	public void test() {
		
	}

}
