package quize.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import quize.bean.Question;
import quize.bean.Quize;

@Service
public class QuizeService {
	
	@Autowired
	QuestionRepo questionRepo;
	
	@Autowired
	QuizeRepo quizeRepo;

	public void saveQuestion(Question question) {
		questionRepo.save(question);
	}

	public void saveQuize(Quize quize) {
		quizeRepo.save(quize);
	}
	
}
