package quize.repo;
import quize.bean.Question;

import org.springframework.data.repository.CrudRepository;  
public interface QuestionRepo extends CrudRepository<Question, Integer>{
	
}
