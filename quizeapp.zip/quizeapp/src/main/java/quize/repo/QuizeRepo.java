package quize.repo;

import org.springframework.data.repository.CrudRepository;

import quize.bean.Quize;

public interface QuizeRepo extends CrudRepository<Quize, Integer>{

}
