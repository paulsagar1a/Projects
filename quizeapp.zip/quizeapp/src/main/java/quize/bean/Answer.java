package quize.bean;

import java.util.Map;

import javax.persistence.Entity;

public class Answer {
	private int id;
	private int quizeId;
	private Map<Integer, String> map;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getQuizeId() {
		return quizeId;
	}
	public void setQuizeId(int quizeId) {
		this.quizeId = quizeId;
	}
	public Map<Integer, String> getMap() {
		return map;
	}
	public void setMap(Map<Integer, String> map) {
		this.map = map;
	}
	
	
}
