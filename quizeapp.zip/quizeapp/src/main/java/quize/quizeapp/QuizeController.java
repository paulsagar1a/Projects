package quize.quizeapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import quize.bean.Question;
import quize.bean.Quize;
import quize.repo.QuizeService;

@RestController
public class QuizeController {
	
	@Autowired
	QuizeService  quizeService;
	
	//create question
	//create quize
	//list of quize
	//quizesubmiission
	
	
	@PostMapping("/create_question")
	public void createQuestion(Question question) {
		quizeService.saveQuestion(question);
	}
	
	@PostMapping("/create_quize")
	public void createQuize(Quize quize) {
		quizeService.saveQuize(quize);
	}
	
	
}
