package com.rabbitmqListener.rabbitmqListener;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitmqListenerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabbitmqListenerApplication.class, args);
	}

}
